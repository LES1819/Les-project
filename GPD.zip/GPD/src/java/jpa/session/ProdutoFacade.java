/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.session;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jpa.entities.Atividade;
import jpa.entities.Produto;

/**
 *
 * @author tiago
 */
@Stateless
public class ProdutoFacade extends AbstractFacade<Produto> {

    @PersistenceContext(unitName = "GPDPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProdutoFacade() {
        super(Produto.class);
    }
    
    // start of our code
    
    public List getNotAssociated(Atividade a) {
        return em.createNamedQuery("Produto.notAssociated").setParameter("atividade",a).getResultList();
    }
    
    public int countNotAssociate(Atividade a) {
        return getNotAssociated(a).size();
    }
    
    /*novo*/
    public void destroyProduto(Produto produto){
        em.createNamedQuery("Produto.destroyAssociations").setParameter("produto",produto);
    }
    /*novo*/
}
